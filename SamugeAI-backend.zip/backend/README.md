# SamugeAI backend

Node.js + Express backend for the SamugeAI bilingual Kinyarwanda/English chatbot.

## Render settings

- Runtime: Node
- Root Directory: `backend`
- Build Command: `npm install`
- Start Command: `npm start`

## Environment variables

Set these in Render (do not upload secrets to GitHub):

- `OPENAI_API_KEY` = your secret OpenAI API key
- `FRONTEND_ORIGIN` = `https://nshiyimiyamasamuel272-hue.github.io`
- `OPENAI_MODEL` = `gpt-4.1-mini` (optional)

Render supplies `PORT` automatically.

## API

- `GET /health`
- `POST /api/chat`
- `POST /chat`

Example request:

```json
{
  "message": "Muraho, witwa nde?"
}
```

The response contains `reply`, `response`, and `answer` fields.

**Important:** Your frontend `script.js` must send requests to the deployed Render URL and use the matching endpoint/payload. Check its exact request format before considering the integration complete.
