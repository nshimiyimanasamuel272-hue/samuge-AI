const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";

// Set FRONTEND_ORIGIN on Render to your GitHub Pages site origin.
const allowedOrigins = (process.env.FRONTEND_ORIGIN ||
  "https://nshiyimiyamasamuel272-hue.github.io")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

app.use(cors({
  origin(origin, callback) {
    // Allow tools such as curl/health checks that do not send an Origin header.
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("Origin not allowed by CORS"));
  }
}));
app.use(express.json({ limit: "1mb" }));

app.get("/", (_req, res) => {
  res.json({ service: "SamugeAI backend", status: "running" });
});

app.get("/health", (_req, res) => {
  res.json({ status: "ok" });
});

async function chatHandler(req, res) {
  try {
    if (!API_KEY) {
      return res.status(500).json({ error: "Server is missing OPENAI_API_KEY." });
    }

    const body = req.body || {};
    let messages = Array.isArray(body.messages) ? body.messages : [];

    // Support simple frontend payloads as well as a messages array.
    if (messages.length === 0) {
      const userText = body.message || body.prompt || body.question;
      if (typeof userText === "string" && userText.trim()) {
        messages = [{ role: "user", content: userText.trim() }];
      }
    }

    messages = messages
      .filter((m) => m && ["user", "assistant", "system"].includes(m.role))
      .map((m) => ({
        role: m.role,
        content: typeof m.content === "string" ? m.content : String(m.content ?? "")
      }))
      .filter((m) => m.content.trim());

    if (messages.length === 0) {
      return res.status(400).json({ error: "Send a message or a messages array." });
    }

    const systemMessage = {
      role: "system",
      content: "You are SamugeAI, a helpful bilingual assistant. Reply in the language used by the user, especially Kinyarwanda or English. Be clear, accurate, and friendly."
    };

    const apiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [systemMessage, ...messages],
        temperature: 0.7
      })
    });

    const data = await apiResponse.json();

    if (!apiResponse.ok) {
      console.error("OpenAI API error:", data);
      return res.status(apiResponse.status).json({
        error: data.error?.message || "The AI service returned an error."
      });
    }

    const reply = data.choices?.[0]?.message?.content?.trim();
    if (!reply) {
      return res.status(502).json({ error: "The AI service returned an empty response." });
    }

    // Multiple common property names make integration easier with different frontends.
    return res.json({ reply, response: reply, answer: reply });
  } catch (error) {
    console.error("Chat request failed:", error);
    return res.status(500).json({ error: "An unexpected server error occurred." });
  }
}

app.post("/api/chat", chatHandler);
app.post("/chat", chatHandler);

app.listen(PORT, () => {
  console.log(`SamugeAI backend listening on port ${PORT}`);
});
