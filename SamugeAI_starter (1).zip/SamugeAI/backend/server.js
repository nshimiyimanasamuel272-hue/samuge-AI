import express from "express";
import cors from "cors";
import OpenAI from "openai";
import "dotenv/config";

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.warn("WARNING: OPENAI_API_KEY is not set. Add it to the backend host's environment variables.");
}
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Set FRONTEND_ORIGIN to your exact GitHub Pages URL in production.
// Example: https://YOUR-USERNAME.github.io
const allowedOrigin = process.env.FRONTEND_ORIGIN || "*";
app.use(cors({ origin: allowedOrigin }));
app.use(express.json({ limit: "20kb" }));

app.get("/", (_req, res) => res.json({ service: "SamugeAI API", status: "ok" }));

app.post("/api/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    const language = req.body?.language === "rw" ? "Kinyarwanda" : "English";
    if (!message) return res.status(400).json({ error: "Message is required." });
    if (message.length > 4000) return res.status(413).json({ error: "Message is too long." });
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "AI service is not configured." });

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: `You are SamugeAI, a helpful, honest AI assistant. Reply in ${language} unless the user clearly requests another language. Be clear and respectful. If unsure, say so. Do not claim you searched the live internet unless a search tool is actually enabled.`,
      input: message
    });
    res.json({ reply: response.output_text || "I could not generate a response. Please try again." });
  } catch (error) {
    console.error("Chat API error:", error?.message || error);
    res.status(500).json({ error: "The AI request failed. Please try again later." });
  }
});

app.listen(port, () => console.log(`SamugeAI API listening on port ${port}`));
