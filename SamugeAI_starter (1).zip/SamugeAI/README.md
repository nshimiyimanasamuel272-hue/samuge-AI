# SamugeAI

A bilingual English/Kinyarwanda AI chatbot website.

## Important architecture note

GitHub Pages hosts static files only. It cannot run the private server needed to safely call an AI API. This project therefore separates:

- `index.html`, `robots.txt`, and `sitemap.xml`: deploy to GitHub Pages.
- `backend/`: deploy to a Node.js backend host such as Render, Railway, or another trusted service.

Never put your OpenAI API key in `index.html` or commit it to GitHub.

## 1. Publish the website with GitHub Pages

1. Upload `index.html`, `robots.txt`, and `sitemap.xml` to the root of your GitHub repository.
2. In `index.html`, replace `YOUR-USERNAME` and `YOUR-REPOSITORY` in the canonical URL and structured data URL with your GitHub username and repository name.
3. Replace the same placeholders in `robots.txt` and `sitemap.xml`.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
6. Wait for deployment and open the URL shown in Settings → Pages. It usually looks like `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`.

## 2. Deploy the backend

Deploy the `backend` folder as a Node.js service. Set the service root directory to `backend` if the hosting platform supports a root-directory setting. Use `npm install` to install dependencies and `npm start` to start the server.

Add environment variables in the backend host's dashboard:

- `OPENAI_API_KEY`: your secret API key from the OpenAI API platform.
- `OPENAI_MODEL`: `gpt-4.1-mini` or another model available to your API account.
- `FRONTEND_ORIGIN`: your exact deployed website origin. Example for a project site: `https://YOUR-USERNAME.github.io`.
- `PORT`: usually provided automatically by the host; otherwise use `3000`.

The API provider may require billing or available credits. ChatGPT subscriptions and API billing are separate.

After the backend deploys, test its root URL. It should return JSON with `"status":"ok"`.

## 3. Connect the frontend to the backend

In `index.html`, find:

```js
const API_BASE_URL = "https://YOUR-BACKEND-URL";
```

Replace it with the backend service's real HTTPS URL, without a trailing slash. Example format:

```js
const API_BASE_URL = "https://your-service.example.com";
```

Commit the changes and reload the published site.

## 4. Test

1. Open the published website.
2. Choose English or Ikinyarwanda.
3. Ask a simple question.
4. If it fails, check the backend logs, the `API_BASE_URL`, the `FRONTEND_ORIGIN`, and that `OPENAI_API_KEY` is set on the backend host.

## SEO notes

- Keep one clear H1 and use H2/H3 for sections and subsections.
- Replace all placeholder URLs with the actual public website URL.
- Add the sitemap in Google Search Console after the site is published.
- Search indexing is not instant or guaranteed.
- This starter chatbot does not have live web search enabled; it answers using the configured AI model.
